//
//  AudioPlayer.swift
//  RestartApp
//
//  Created by Chardson Miranda (P) on 27/04/22.
//

import Foundation
import AVFoundation

var audioPlayer: AVAudioPlayer?

func playSound(sound: String, type: String) {
    
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audioPlayer?.play()
        } catch {
            print("Nao foi possivel reproduzir esse som")
        }
    }
    
}
