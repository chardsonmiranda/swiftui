//
//  RestartAppApp.swift
//  RestartApp
//
//  Created by Chardson Miranda (P) on 25/04/22.
//

import SwiftUI

@main
struct RestartAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
